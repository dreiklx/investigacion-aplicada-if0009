import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
  getFirestore,
  collection,
  getDocs,
  addDoc,
  query,
  orderBy,
  serverTimestamp,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

/* ---------- Firebase ---------- */
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

/* ---------- Elementos ---------- */
const $ = (id) => document.getElementById(id);
const selProducto = $("selProducto");
const inpCantidad = $("inpCantidad");
const btnAgregar = $("btnAgregar");
const cuerpoPedido = $("cuerpoPedido");
const tablaWrap = $("tablaWrap");
const pedidoVacio = $("pedidoVacio");
const totalPedido = $("totalPedido");
const formPedido = $("formPedido");
const inpCliente = $("inpCliente");
const inpDireccion = $("inpDireccion");
const btnEnviar = $("btnEnviar");
const spinnerEnviar = $("spinnerEnviar");
const avisoGlobal = $("avisoGlobal");

/* ---------- Estado ---------- */
let productos = []; // { id, nombre, precio }
let pedido = []; // { id, nombre, precio, cantidad }

const moneda = new Intl.NumberFormat("es-CR", {
  style: "currency",
  currency: "CRC",
  maximumFractionDigits: 0,
});
const redondear = (n) => Math.round(n * 100) / 100;

function mostrarError(texto) {
  avisoGlobal.textContent = texto;
  avisoGlobal.classList.remove("d-none");
}

/* ---------- 1. Cargar productos desde Firestore ---------- */
async function cargarProductos() {
  try {
    const consulta = query(collection(db, "productos"), orderBy("nombre"));
    const resultado = await getDocs(consulta);

    productos = resultado.docs.map((d) => ({
      id: d.id,
      nombre: String(d.data().nombre ?? ""),
      precio: Number(d.data().precio ?? 0),
    }));

    selProducto.replaceChildren();

    if (productos.length === 0) {
      selProducto.append(new Option("No hay productos registrados", ""));
      return;
    }

    selProducto.append(new Option("Selecciona un producto…", ""));
    productos.forEach((p) => {
      selProducto.append(
        new Option(`${p.nombre} – ${moneda.format(p.precio)}`, p.id),
      );
    });

    selProducto.disabled = false;
    btnAgregar.disabled = false;
  } catch (error) {
    console.error(error);
    selProducto.replaceChildren(
      new Option("No se pudieron cargar los productos", ""),
    );
    mostrarError(
      "No se pudieron cargar los productos. Revisa tu conexión o las reglas de Firestore.",
    );
  }
}

/* ---------- 2. Armar el pedido ---------- */
btnAgregar.addEventListener("click", () => {
  const producto = productos.find((p) => p.id === selProducto.value);
  const cantidad = Number(inpCantidad.value);

  if (!producto) {
    selProducto.focus();
    return;
  }
  if (!Number.isInteger(cantidad) || cantidad < 1 || cantidad > 99) {
    inpCantidad.focus();
    return;
  }

  // Si el producto ya está en el pedido, se suma la cantidad
  const existente = pedido.find((l) => l.id === producto.id);
  if (existente) {
    existente.cantidad = Math.min(99, existente.cantidad + cantidad);
  } else {
    pedido.push({ ...producto, cantidad });
  }

  selProducto.value = "";
  inpCantidad.value = 1;
  dibujarPedido();
});

function dibujarPedido() {
  cuerpoPedido.replaceChildren();

  pedido.forEach((linea, indice) => {
    const fila = document.createElement("tr");

    const tdNombre = document.createElement("td");
    tdNombre.textContent = linea.nombre;

    const tdCantidad = document.createElement("td");
    tdCantidad.className = "text-end";
    tdCantidad.textContent = linea.cantidad;

    const tdSubtotal = document.createElement("td");
    tdSubtotal.className = "text-end";
    tdSubtotal.textContent = moneda.format(
      redondear(linea.precio * linea.cantidad),
    );

    const tdQuitar = document.createElement("td");
    tdQuitar.className = "text-end";
    const btnQuitar = document.createElement("button");
    btnQuitar.type = "button";
    btnQuitar.className = "btn btn-sm btn-outline-danger";
    btnQuitar.textContent = "Quitar";
    btnQuitar.setAttribute("aria-label", `Quitar ${linea.nombre}`);
    btnQuitar.addEventListener("click", () => {
      pedido.splice(indice, 1);
      dibujarPedido();
    });
    tdQuitar.append(btnQuitar);

    fila.append(tdNombre, tdCantidad, tdSubtotal, tdQuitar);
    cuerpoPedido.append(fila);
  });

  totalPedido.textContent = moneda.format(calcularTotal());
  tablaWrap.classList.toggle("d-none", pedido.length === 0);
  pedidoVacio.classList.toggle("d-none", pedido.length > 0);
  actualizarBotonEnviar();
}

function calcularTotal() {
  return redondear(pedido.reduce((suma, l) => suma + l.precio * l.cantidad, 0));
}

function actualizarBotonEnviar() {
  const datosListos =
    inpCliente.value.trim() !== "" && inpDireccion.value.trim() !== "";
  btnEnviar.disabled = pedido.length === 0 || !datosListos;
}
inpCliente.addEventListener("input", actualizarBotonEnviar);
inpDireccion.addEventListener("input", actualizarBotonEnviar);

/* ---------- 3. Notificaciones del navegador ---------- */
async function notificar(titulo, cuerpo) {
  if (!("Notification" in window) || Notification.permission !== "granted")
    return;
  const opciones = { body: cuerpo, icon: "icons/icon.png" };
  try {
    // En Android solo funciona desde el registro del service worker
    const registro = await navigator.serviceWorker?.getRegistration();
    if (registro) {
      await registro.showNotification(titulo, opciones);
    } else {
      new Notification(titulo, opciones);
    }
  } catch (error) {
    console.warn("No se pudo mostrar la notificación", error);
  }
}

/* ---------- 4. Enviar el pedido ---------- */
/* ---------- 4. Enviar el pedido ---------- */
formPedido.addEventListener("submit", async (evento) => {
  evento.preventDefault();
  if (btnEnviar.disabled) return;

  // El permiso se pide dentro del clic del usuario (los navegadores lo exigen)
  if ("Notification" in window && Notification.permission === "default") {
    await Notification.requestPermission();
  }

  btnEnviar.disabled = true;
  spinnerEnviar.classList.remove("d-none");
  avisoGlobal.classList.add("d-none");

  const cliente = inpCliente.value.trim();
  const total = calcularTotal();
  let referencia;

  // 1) Guardar en Firebase: si falla aquí, el pedido NO se envió
  try {
    referencia = await addDoc(collection(db, "pedidos"), {
      cliente,
      direccion: inpDireccion.value.trim(),
      items: pedido.map((l) => ({
        nombre: l.nombre,
        precio: l.precio,
        cantidad: l.cantidad,
        subtotal: redondear(l.precio * l.cantidad),
      })),
      total,
      estado: "pendiente",
      fecha: serverTimestamp(),
    });
  } catch (error) {
    console.error("Error al guardar el pedido:", error);
    mostrarError("No se pudo enviar el pedido. Intenta de nuevo.");
    spinnerEnviar.classList.add("d-none");
    actualizarBotonEnviar();
    return;
  }

  // 2) Desde aquí el pedido YA está registrado
  spinnerEnviar.classList.add("d-none");

  try {
    $("modalCuerpo").replaceChildren(
      Object.assign(document.createElement("p"), {
        textContent: `Gracias, ${cliente}. Tu pedido fue registrado correctamente.`,
      }),
      Object.assign(document.createElement("p"), {
        className: "mb-0",
        textContent: `Código: ${referencia.id} · Total: ${moneda.format(total)}`,
      }),
    );
    bootstrap.Modal.getOrCreateInstance($("modalConfirmacion")).show();
  } catch (error) {
    console.error("Error al mostrar la confirmación:", error);
    alert("Pedido registrado. Código: " + referencia.id);
  }

  notificar(
    "Pedido registrado",
    `Tu pedido por ${moneda.format(total)} fue recibido.`,
  );

  // Limpiar para un nuevo pedido
  pedido = [];
  formPedido.reset();
  dibujarPedido();
});

/* ---------- Service worker (PWA) ---------- */
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register("sw.js")
      .catch((e) => console.warn("SW no registrado", e));
  });
}

cargarProductos();
