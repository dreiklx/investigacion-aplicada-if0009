// Configuración pública del proyecto de Firebase (no es un secreto).
// La seguridad real depende de las reglas de Firestore.
export const firebaseConfig = {
  apiKey: "AIzaSyCq0mvtPr3SCZGo2BtA2hh7KjrWZQGlngo",
  authDomain: "pwa-practica-comercio.firebaseapp.com",
  projectId: "pwa-practica-comercio",
  storageBucket: "pwa-practica-comercio.firebasestorage.app",
  messagingSenderId: "669463942029",
  appId: "1:669463942029:web:4ddc7795965a0b516563c4"
};
