
// Service worker mínimo: lo necesario para que la app sea instalable
// y para mostrar notificaciones desde el registro del SW (necesario en Android).
// La tarea no pide funcionamiento sin conexión, así que no se guarda nada en caché.

self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (event) => event.waitUntil(self.clients.claim()));

// Las peticiones pasan directo a la red.
self.addEventListener('fetch', () => {});

// Al tocar una notificación, enfoca la app (o la abre).
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((lista) => {
      if (lista.length) return lista[0].focus();
      return self.clients.openWindow('./index.html');
    })
  );
});
