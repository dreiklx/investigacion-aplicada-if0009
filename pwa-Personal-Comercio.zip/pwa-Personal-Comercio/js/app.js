import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
  getFirestore, collection, query, orderBy, onSnapshot, doc, updateDoc, serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

// jQuery ($) y Bootstrap se cargan como scripts normales en index.html

//--------- ESTADO ---------

let pedidos = [];          // { id, cliente, direccion, items, total, estado, fecha }
let primeraCarga = true;   // la primera lectura trae todos los pedidos: no se notifican
const notificados = new Set(); // ids ya notificados en esta sesión (evita repetir)

const moneda = new Intl.NumberFormat("es-CR", {
  style: "currency",
  currency: "CRC",
  maximumFractionDigits: 0,
});

//--------- EVENTOS ---------

$(document).on("click", ".btn-entregar", function () {
  entregar($(this).data("id"), $(this));
});

// El permiso de notificaciones debe pedirse dentro de un clic del usuario
$(document).on("click", "#btnNotificaciones", async function () {
  await Notification.requestPermission();
  mostrarBotonNotificaciones();
});

//--------- DB (FIREBASE) ---------

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Tiempo real: Firestore avisa cada vez que un pedido se crea o cambia
function escuchar() {
  const consulta = query(collection(db, "pedidos"), orderBy("fecha", "desc"));

  onSnapshot(
    consulta,
    function (snapshot) {
      pedidos = snapshot.docs.map((d) => ({ id: d.id, ...d.data() }));
      loadPedidos();

      if (!primeraCarga) {
        snapshot.docChanges().forEach(function (cambio) {
          if (cambio.type !== "added") return;
          if (notificados.has(cambio.doc.id)) return;
          notificados.add(cambio.doc.id);

          const pedido = cambio.doc.data();
          resaltar(cambio.doc.id);
          notificar("Nuevo pedido", pedido.cliente + " · " + moneda.format(pedido.total || 0));
        });
      }

      primeraCarga = false;
    },
    function (error) {
      console.error(error);
      $("#cargando").addClass("d-none");
      mostrarError("No se pudieron cargar los pedidos. Revisa tu conexión o las reglas de Firestore.");
    }
  );
}

//--------- CRUD ---------

// Actualizar: cambia el estado del pedido en Firestore
function update(id, cambios) {
  return updateDoc(doc(db, "pedidos", id), cambios);
}

async function entregar(id, $boton) {
  const pedido = pedidos.find((p) => p.id === id);
  if (!pedido) return;

  $boton.prop("disabled", true);

  try {
    await update(id, { estado: "entregado", fechaEntrega: serverTimestamp() });

    mostrarEntrega(pedido);
    notificar("Pedido entregado", "Pedido " + id + " · " + pedido.cliente);
  } catch (error) {
    console.error(error);
    mostrarError("No se pudo actualizar el pedido. Intenta de nuevo.");
    $boton.prop("disabled", false);
  }
}

//--------- VIEWS ---------

function formatearFecha(fecha) {
  // La fecha llega como Timestamp de Firestore; puede ser null unos instantes
  return fecha && fecha.toDate ? fecha.toDate().toLocaleString("es-CR") : "—";
}

function loadPedidos() {
  const $lista = $("#listaPedidos").empty();

  $("#cargando").addClass("d-none");
  $("#sinPedidos").toggleClass("d-none", pedidos.length > 0);

  const pendientes = pedidos.filter((p) => p.estado === "pendiente").length;
  $("#contador").text(pendientes + (pendientes === 1 ? " pedido pendiente" : " pedidos pendientes"));

  pedidos.forEach(function (pedido) {
    const entregado = pedido.estado === "entregado";

    // Cabecera: identificador, estado y fecha
    const $cabecera = $("<div>").addClass("card-header d-flex justify-content-between align-items-start gap-2").append(
      $("<div>").append(
        $("<div>").addClass("font-monospace small").text("Pedido " + pedido.id),
        $("<small>").addClass("text-muted").text(formatearFecha(pedido.fecha))
      ),
      $("<span>")
        .addClass("badge " + (entregado ? "text-bg-success" : "text-bg-warning"))
        .text(entregado ? "Entregado" : "Pendiente")
    );

    // Productos solicitados
    const $items = $("<ul>").addClass("list-unstyled mb-3");
    (pedido.items || []).forEach(function (item) {
      if (typeof item !== "object" || item === null) return; // ignora datos mal formados
      $items.append(
        $("<li>").addClass("d-flex justify-content-between").append(
          $("<span>").text(item.cantidad + " × " + item.nombre),
          $("<span>").text(moneda.format(item.subtotal || 0))
        )
      );
    });

    const $cuerpo = $("<div>").addClass("card-body").append(
      $("<h2>").addClass("h6 mb-1").text(pedido.cliente),
      $("<p>").addClass("text-muted small mb-3").text(pedido.direccion),
      $items,
      $("<div>").addClass("d-flex justify-content-between fw-bold border-top pt-2").append(
        $("<span>").text("Total"),
        $("<span>").text(moneda.format(pedido.total || 0))
      )
    );

    const $tarjeta = $("<div>")
      .addClass("card tarjeta-pedido h-100 shadow-sm" + (entregado ? " entregado" : ""))
      .attr("data-pedido", pedido.id)
      .append($cabecera, $cuerpo);

    if (!entregado) {
      $tarjeta.append(
        $("<div>").addClass("card-footer bg-transparent").append(
          $("<button>")
            .attr("type", "button")
            .addClass("btn btn-marca w-100 btn-entregar")
            .data("id", pedido.id)
            .text("Marcar como entregado")
        )
      );
    }

    $lista.append($("<div>").addClass("col-12 col-lg-6").append($tarjeta));
  });
}

function resaltar(id) {
  $(".tarjeta-pedido")
    .filter(function () { return $(this).attr("data-pedido") === id; })
    .addClass("nuevo");
}

function mostrarEntrega(pedido) {
  $("#modalEntregaCuerpo").empty().append(
    $("<p>").addClass("mb-1").text("El pedido fue marcado como entregado."),
    $("<p>").addClass("mb-0").append(
      $("<strong>").text("Pedido: "), document.createTextNode(pedido.id),
      $("<br>"),
      $("<strong>").text("Cliente: "), document.createTextNode(pedido.cliente)
    )
  );

  bootstrap.Modal.getOrCreateInstance(document.getElementById("modalEntrega")).show();
}

function mostrarError(texto) {
  $("#avisoGlobal").text(texto).removeClass("d-none");
}

function mostrarBotonNotificaciones() {
  const sePuede = "Notification" in window && Notification.permission === "default";
  $("#btnNotificaciones").toggleClass("d-none", !sePuede);
}

//--------- NOTIFICACIONES ---------

async function notificar(titulo, mensaje) {
  try {
    if (!("Notification" in window) || Notification.permission !== "granted") return;

    // Se muestra desde el registro del service worker (necesario en Android)
    const registro = await navigator.serviceWorker.ready;

    await registro.showNotification(titulo, {
      body: mensaje,
      icon: "icons/icon.png",
    });
  } catch (error) {
    console.error("Error al notificar:", error);
  }
}

//--------- SERVICE WORKER ---------

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("sw.js").catch(function (error) {
    console.warn("No se pudo registrar el service worker", error);
  });
}

//--------- INICIO ---------

$(function () {
  mostrarBotonNotificaciones();
  escuchar();
});
