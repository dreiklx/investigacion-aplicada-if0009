// Configuración pública del proyecto de Firebase (no es un secreto).
// La seguridad real depende de las reglas de Firestore.
export const firebaseConfig = {
  apiKey: "AIzaSyCrlU2j63eHfnX8CZ7_76S-flxQZmpzAgA",
  authDomain: "supermercado-congo-loco-if0009.firebaseapp.com",
  projectId: "supermercado-congo-loco-if0009",
  storageBucket: "supermercado-congo-loco-if0009.firebasestorage.app",
  messagingSenderId: "825187366844",
  appId: "1:825187366844:web:0211fa0cac94eec34e1db9"
};
