// Service worker mínimo: hace la app instalable y permite mostrar notificaciones
// desde su registro (necesario en Android). No guarda nada en caché porque la tarea
// no pide funcionamiento sin conexión.

self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (event) => event.waitUntil(self.clients.claim()));
self.addEventListener('fetch', () => {});

// Al tocar una notificación, enfoca la app (o la abre).
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((lista) => {
      if (lista.length) return lista[0].focus();
      return self.clients.openWindow('./index.html');
    })
  );
});
